﻿namespace resume.Others
{
    public class CombineDictionary
    {
        public Dictionary<string, object> BasicResult { get; set; }
        public Dictionary<string, object> JobMatchResult { get; set; }
    }
}
