﻿namespace resume.Others
{
    public class HomeJobCount
    {
        public DateTime Date { get; set; }//日期
        public int Count { get; set; }//当天新增岗位数量

    }
}
