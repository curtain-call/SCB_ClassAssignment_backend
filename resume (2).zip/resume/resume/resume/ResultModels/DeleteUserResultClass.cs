﻿namespace resume.ResultModels
{
    public class DeleteUserResultClass
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
