﻿namespace resume.ResultModels
{
    public class JobIdResultClass
    {
        public int Id { get; set; }//成功的响应应返回新创建的岗位的ID
    }
}
