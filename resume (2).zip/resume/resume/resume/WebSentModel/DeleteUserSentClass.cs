﻿namespace resume.WebSentModel
{
    public class DeleteUserSentClass
    {
        public int Id { get; set; }//所需要删除用户的ID
    }
}
