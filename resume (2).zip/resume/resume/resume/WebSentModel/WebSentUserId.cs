﻿namespace resume.WebSentModel
{
    public class WebSentUserId
    {
        public int Id { get; set; }
    }
}
