﻿namespace resume.Models
{
    public class AwardInfo
    {
        public string? AwardName { get; set; }
    }
}
