import os
import openai
import re  # 导入正则表达式模块
import sys
import time
import json
import docx2txt

import shutil

import io

import sys
import codecs
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())



start_time = time.time()  # 添加这行代码
print(start_time)


# 读取命令行参数

filepath = sys.argv[1].strip()
print(filepath)
r_id = sys.argv[2].strip()
print(r_id)
extention = sys.argv[3].replace(' ', '')

print(extention)
n = sys.argv[4].strip()
print(n)




key = sys.argv[5].strip()

os.environ["OPENAI_API_BASE"]="https://api.openai.com/v1"
openai.api_key = key

# openai.api_key = "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"



# # # print(filepath)
# 使用 os.path.dirname 和 os.path.join 构建新的路径
base_dir = os.path.dirname(filepath)
prompt_txt = os.path.join(base_dir, f'{n}.txt')




# 现在，resume_txt将指向新生成的txt文件
resume_txt_path = os.path.join(base_dir, f'txt\\{r_id}.txt')
print(resume_txt_path)


# 打开文件并读取内容
with open(resume_txt_path, 'r', encoding='utf-8') as file: 
    resume_text = file.read()




def openai_request(prompt):
    message = [
        {"role": "system", "content": prompt},
        {"role": "user", "content": f"我这里有一份简历，我需要获取其中的一些信息。简历如下：{resume_text}"},
    ]

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo-16k",
        messages=message,
        temperature=0.01,
        max_tokens=3000,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0,
    )


    return response['choices'][0]['message']['content']



# 读取txt的prompt文件
with open(prompt_txt, 'r', encoding='utf-8') as file:
    prompt = file.read().replace('\n', '')


answer = openai_request(prompt)


# 获取当前目录的绝对路径
current_dir = os.getcwd()

if "{" in answer and "}" in answer:
    sys.stdout.write("找到了可能的 JSON 数据\n")
    sys.stdout.flush()
else:   
    if n == "1004":
        file_path = os.path.join(current_dir, '1004.json')
        with open(file_path, 'r', encoding="utf-8") as file:
            data = json.load(file)

        pretty_json = json.dumps(data, ensure_ascii=False)
        sys.stdout.write(pretty_json+"\n")
        sys.stdout.flush()
    elif n == "1005":
        file_path = os.path.join(current_dir, '1005.json')
        with open(file_path, 'r', encoding="utf-8") as file:
            data = json.load(file)

        pretty_json = json.dumps(data, ensure_ascii=False)
        sys.stdout.write(pretty_json+"\n")
        sys.stdout.flush()
    elif n == "1006":
        file_path = os.path.join(current_dir, '1006.json')
        with open(file_path, 'r', encoding="utf-8") as file:
            data = json.load(file)

        pretty_json = json.dumps(data, ensure_ascii=False)
        sys.stdout.write(pretty_json+"\n")
        sys.stdout.flush()

sys.stdout.write(answer+"\n")
sys.stdout.flush()





end_time = time.time()  # 添加这行代码
print(end_time)

print('Total execution time: ' + str(end_time - start_time) + ' seconds')  # 添加这行代码