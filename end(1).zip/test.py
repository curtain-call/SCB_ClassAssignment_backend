



# # import openai
# # if __name__ == "__main__":
# #     openai.api_base = "http://125.220.157.228:58000/v1"
# #     openai.api_key = "none"
# #     for chunk in openai.ChatCompletion.create(
# #         model="chatglm2-6b",
# #         messages=[
# #             {"role": "user", "content": "请简要介绍一下武汉大学"}
# #         ],
# #         stream=True
# #     ):
# #         if hasattr(chunk.choices[0].delta, "content"):
# #             print(chunk.choices[0].delta.content, end="", flush=True)


# import json 



# with open('E:\\softbei\\code\\end\\1004.json', 'r', encoding="utf-8") as file:
# # 使用json.load读取文件内容并解析为Python对象
#     data = json.load(file)
#     print(data)

# # 现在`data`变量包含了JSON文件中的数据，可以使用它进行后续操作
# print(data)



# if n == "1004":
#     with open('E:\\softbei\\code\\end\\1004.json', 'r', encoding="utf-8") as file:
#     # 使用json.load读取文件内容并解析为Python对象
#         data = json.load(file)
#         print(data)
#         print(data)

#     # 现在`data`变量包含了JSON文件中的数据，可以使用它进行后续操作
#     print(data)


import sys
import os

print(sys.getdefaultencoding())

os.getcwd()

print(os.getcwd())