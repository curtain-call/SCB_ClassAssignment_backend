﻿namespace resume.Others
{
    public class WorkExperience
    {
        public int Id { get; set; }
        public int ApplicantID { get; set; }
        public string CompanyName { get; set; }
        public string Position { get; set; }
        public string Time { get; set; }
        public string Task { get; set; }
    }
}
