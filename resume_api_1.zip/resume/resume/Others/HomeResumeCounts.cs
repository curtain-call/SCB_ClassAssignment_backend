﻿namespace resume.Others
{
    public class HomeResumeCounts
    {
        public string Date { get; set; }//日期
        public int Count { get; set; }//当天新增岗位数量
    }
}
