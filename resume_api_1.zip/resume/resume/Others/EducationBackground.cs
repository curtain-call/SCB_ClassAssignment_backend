﻿namespace resume.Others
{
    public class EducationBackground
    {
        public int Id { get; set; }
        public int ApplicantID { get; set; }

        public string Time { get; set; }
        public string School { get; set; }
        public string Major { get; set; }
   
    }
}
