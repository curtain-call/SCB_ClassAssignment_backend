﻿namespace resume.Others
{
    public class HomeWeeklyState
    {
        public List<HomeJobCount> JobCounts { get; set; }
        public List<HomeResumeCounts> resumeCounts { get; set; }
    }

}
