﻿namespace resume.Others
{
    public class BriefHomeResumeInfo
    {
        public int RId { get; set; }//简历ID
        public string ResumeName { get; set; }//求职者名字
        public string JobIntenTion { get; set; }//求职者的意向岗位
        public string UploadDate { get; set; }//该简历上传的时间
    }
}
