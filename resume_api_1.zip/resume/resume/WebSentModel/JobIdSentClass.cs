﻿namespace resume.WebSentModel
{
    public class JobIdSentClass
    {
        public int UserId { get; set; }
        public int JobId { get; set; }
    }
}
