﻿using System.Numerics;
using resume.Others;
namespace resume.ResultModels
{
    public class MainViewToResumeModelClass
    {
        public List<SimpleResume> ResumesInfo=new List<SimpleResume>();
        public int Test;
    }

    

}
