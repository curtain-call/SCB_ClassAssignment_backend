﻿namespace resume.Models
{
    public class Award
    {
        public int ID { get; set; }
        public int ApplicantID { get; set; }
        public string? AwardName { get; set; }
        //public Applicant Applicant { get; set; }
    }
}
