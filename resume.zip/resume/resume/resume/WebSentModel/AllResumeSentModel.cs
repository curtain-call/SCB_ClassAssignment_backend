﻿namespace resume.WebSentModel
{
    public class AllResumeSentModel
    {
        public int UserId { get; set; }//该id用来查询数据库
        public string GetResume { get; set; } //用途暂未确定
    }
}
