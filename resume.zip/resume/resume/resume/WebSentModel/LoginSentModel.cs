﻿namespace resume.WebSentModel
{
    public class LoginSentModel
    {
        public string Password { get; set; }
        public string UserName { get; set; }
    }
}
