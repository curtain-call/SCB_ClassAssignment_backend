﻿namespace resume.WebSentModel
{
    public class RegisterSentModel
    {
        public string Name { get; set; }
        public string Account { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
