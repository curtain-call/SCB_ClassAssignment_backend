﻿namespace resume.WebSentModel
{
    public class UploadResumeSentModel
    {
        public int UserId { get; set; }
        public IFormFile  iFormFile { get; set; }
    }
}
