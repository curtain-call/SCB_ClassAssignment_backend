﻿namespace resume.WebSentModel
{
    public class WebSentUserId
    {
        public int Id { get; set; }
    }

    public class WebSentResumeId
    {
        public int Id { get; set; }
    }
}
