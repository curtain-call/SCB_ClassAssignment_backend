﻿namespace resume.Models
{
    public class SkillCertificate
    {
        public int ID { get; set; }
        public int ApplicantID { get; set; }
        public string? SkillName { get; set; }
        //public Applicant Applicant { get; set; }
    }
}
