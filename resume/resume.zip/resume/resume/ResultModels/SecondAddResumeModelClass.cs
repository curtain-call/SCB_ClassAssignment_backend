﻿namespace resume.ResultModels
{
    public class SecondAddResumeModelClass
    {
        public int Code { get; set; }//表示是否添加成功,20000为成功，
    }
}
