﻿namespace resume.Others
{
    public class Job
    {
    }
}
