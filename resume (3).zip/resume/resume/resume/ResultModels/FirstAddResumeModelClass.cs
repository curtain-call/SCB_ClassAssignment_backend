﻿using resume.Others;

namespace resume.ResultModels
{
    public class FirstAddResumeModelClass
    {
        public int Code { get; set; }
        public DetailedResume DetailedResume { get; set; }
    }
}
