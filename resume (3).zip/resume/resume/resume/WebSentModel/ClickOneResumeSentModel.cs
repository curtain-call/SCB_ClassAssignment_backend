﻿namespace resume.WebSentModel
{
    public class ClickOneResumeSentModel
    {
        public int RId { get; set; }//传输过来需要返回的简历ID
    }
}
